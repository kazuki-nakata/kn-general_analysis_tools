import setuptools

if __name__ == "__main__":
    setuptools.setup(
        name="pykna",
        version='0.1',
        description='This project summarizes remote sensing data analysis tools',
        author='Kazuki Nakata',
        author_email='knakata0924@gmail.com',
        url='https://github.com/kazuki-nakata/',
        packages=setuptools.find_packages(),
#        install_requires=open('requirements.txt').read().splitlines()
    )
